// language.js

// Make the initialization function globally accessible
window.initLanguagePage = function() {
    const languageSettingsForm = document.getElementById('languageSettingsForm');
    const selectLanguage = document.getElementById('selectLanguage');

    // Remove any previous event listeners to prevent multiple bindings if the page is loaded multiple times
    // This is crucial for AJAX-loaded content
    $(languageSettingsForm).off('submit'); 

    // Handle form submission
    if (languageSettingsForm) {
        $(languageSettingsForm).on('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            const selectedLanguage = selectLanguage.value;
            
            // In a real application, you would send this data to a server
            console.log('Language selected:', selectedLanguage);

            // Simulate an API call or update
            setTimeout(() => {
                // Use the globally available showToast function from script.js
                if (typeof window.showToast === 'function') {
                    window.showToast(`Language updated to ${selectedLanguage.toUpperCase()}!`, 'success');
                } else {
                    alert(`Language updated to ${selectedLanguage.toUpperCase()}!`);
                }
                // Optionally, update the UI to reflect the change or redirect
            }, 500);
        });
    }

    // You can add more JavaScript logic specific to the language page here
    // For example, dynamically loading language options, saving preferences to local storage, etc.
};

// If language.js is loaded dynamically via $.getScript, you might not need the DOMContentLoaded listener here.
// If it's loaded traditionally in the head/body, then the DOMContentLoaded is good practice.
// However, since script.js calls initLanguagePage() AFTER the HTML is loaded into #main-content,
// the elements will already exist, so DOMContentLoaded inside initLanguagePage is not strictly necessary.
// But keeping it doesn't hurt.
// document.addEventListener('DOMContentLoaded', function() {
//     // For a standalone page, you might call initLanguagePage() here
//     // But since script.js controls loading, it calls this directly.
// });