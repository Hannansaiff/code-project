// script.js

$(document).ready(function () {
    // Function to capitalize first letter
    function capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    // Function to show toast messages (made available globally for profile.js, general.js, and language.js)
    window.showToast = function(message, type = 'success') {
        // Remove any existing toast containers to prevent stacking issues
        $('.toast-container').remove();

        const toastClass = type === 'success' ? 'text-success' : 'text-danger'; // For icon color
        const bgClass = type === 'success' ? 'bg-success' : 'bg-danger'; // For toast background color
        const iconClass = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';
        const toastHtml = `
            <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1080;">
                <div class="toast show text-white ${bgClass} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header ${bgClass} text-white"> <i class="fas ${iconClass} me-2"></i> <strong class="me-auto text-white">${capitalize(type)}</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(toastHtml);
        
        setTimeout(function() {
            $('.toast').removeClass('show').addClass('hide');
            setTimeout(function() {
                $('.toast-container').remove();
            }, 300); // Allow time for fade out
        }, 3000); // Toast remains for 3 seconds
    };

    // This function will load content into #main-content
    function loadContent(target) {
        // Close sidebar if open on mobile
        if ($(window).width() < 992 && $("#wrapper").hasClass("toggled")) { 
            $("#wrapper").removeClass("toggled");
            $("body").removeClass("sidebar-open");
            $('.sidebar-overlay').remove(); // Remove overlay when sidebar closes
        }

        // Update active class in sidebar
        $("[data-target]").removeClass("active");
        $(`[data-target='${target}']`).addClass("active");
        
        // Update page title displayed in the header
        // For 'profile', 'general', 'language', the sub-page title is set inside their $.get callbacks
        if (target !== "profile" && target !== "general" && target !== "language" && target !== "settings") {
            $("#pageTitle").text(capitalize(target));
        } else if (target === "settings") {
            $("#pageTitle").text("Settings");
        }


        // Content for different sections
        if (target === "home") {
            $("#main-content").html(`
                <div class='mt-4'>
                    <h4>Home Page Content</h4>
                    <p>Welcome to your dashboard!</p>
                </div>
            `);
        } else if (target === "settings") {
            const settingsHtml = `
                <div class="header-line d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0">Settings</h3>
                    <div class="input-group search-header-input-settings">
                        <input type="text" class="form-control" placeholder="Search..." aria-label="Search">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
                <div class="settings-container">
                    <div class="setting-item" data-setting="profile">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-primary text-white">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="setting-text">
                                <h5>Profile</h5>
                                <a href="#">Profile Setting, Name</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="general">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-secondary text-white">
                                <i class="fas fa-sliders-h"></i>
                            </div>
                            <div class="setting-text">
                                <h5>General</h5>
                                <a href="#">Date & Time Setting</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="language">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-success text-white">
                                <i class="fas fa-language"></i>
                            </div>
                            <div class="setting-text">
                                <h5>Language</h5>
                                <a href="#">Language & Input Setting</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="notification">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-warning text-white">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="setting-text">
                                <h5>Notification</h5>
                                <a href="#">Sound & Notification</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="privacy">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-danger text-white">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="setting-text">
                                <h5>Privacy</h5>
                                <a href="#">Password & Security</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="about">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-info text-white">
                                <i class="fas fa-info-circle"></i>
                            </div>
                            <div class="setting-text">
                                <h5>About</h5>
                                <a href="#">Information & About</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                    <div class="setting-item" data-setting="regional">
                        <div class="d-flex align-items-center">
                            <div class="setting-icon bg-dark text-white">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="setting-text">
                                <h5>Regional Setting</h5>
                                <a href="#">Set Current Account Region</a>
                            </div>
                        </div>
                        <div class="setting-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                </div>
            `;
            $("#main-content").html(settingsHtml);
            $("#pageTitle").text("Settings"); // Ensure title is set for settings page

        } else if (target === "profile") { 
            $.get('profile.html', function(data) {
                // Wrap the data in jQuery to easily select content
                const loadedHtml = $(data);
                // Extract only the profile-container content
                const profileContent = loadedHtml.filter('.profile-container').html() || loadedHtml.find('.profile-container').html();
                
                // Construct the full page HTML including the back button and title
                const pageHeader = `
                    <div class="header-line d-flex justify-content-between align-items-center mb-4">
                        <div class="d-flex align-items-center">
                            <button class="btn btn-link p-0 me-3 text-decoration-none" id="backToSettings">
                                <i class="fas fa-arrow-left fs-5 text-secondary"></i>
                            </button>
                            <h3 class="fw-bold mb-0">Profile</h3>
                        </div>
                    </div>
                `;
                $("#main-content").html(pageHeader + (profileContent || '')); // Use || '' to prevent 'undefined' if content not found
                $("#pageTitle").text("Profile"); // Update main header title

                // *** CRITICAL STEP: Call the initialization function from profile.js ***
                if (typeof window.initProfilePage === 'function') {
                    window.initProfilePage(); 
                } else {
                    console.error("initProfilePage is not defined. Ensure profile.js is loaded and defines this function globally.");
                }

            }).fail(function() {
                showToast('Failed to load profile page.', 'error');
                $("#main-content").html(`<div class='mt-4 text-danger'><h4>Error Loading Page</h4><p>Could not load the profile content. Please try again.</p></div>`);
            });
        } else if (target === "general") { 
            $.get('general.html', function(data) {
                const loadedHtml = $(data);
                const generalContent = loadedHtml.filter('.general-container').html() || loadedHtml.find('.general-container').html();
                const pageHeader = `
                    <div class="header-line d-flex justify-content-between align-items-center mb-4">
                        <div class="d-flex align-items-center">
                            <button class="btn btn-link p-0 me-3 text-decoration-none" id="backToSettings">
                                <i class="fas fa-arrow-left fs-5 text-secondary"></i>
                            </button>
                            <h3 class="fw-bold mb-0">General</h3>
                        </div>
                    </div>
                `;
                $("#main-content").html(pageHeader + (generalContent || '')); // Use || '' to prevent 'undefined' if content not found
                $("#pageTitle").text("General"); // Update main header title

                // *** CRITICAL STEP: Call the initialization function from general.js ***
                if (typeof window.initGeneralPage === 'function') {
                    window.initGeneralPage();
                } else {
                    console.error("initGeneralPage is not defined. Ensure general.js is loaded and defines this function globally.");
                }

            }).fail(function() {
                showToast('Failed to load general settings page.', 'error');
                $("#main-content").html(`<div class='mt-4 text-danger'><h4>Error Loading Page</h4><p>Could not load the general settings content. Please try again.</p></div>`);
            });
        } else if (target === "language") { // NEW: Handle language page
            $.get('language.html', function(data) {
                const loadedHtml = $(data);
                const languageContent = loadedHtml.filter('.language-container').html() || loadedHtml.find('.language-container').html();
                const pageHeader = `
                    <div class="header-line d-flex justify-content-between align-items-center mb-4">
                        <div class="d-flex align-items-center">
                            <button class="btn btn-link p-0 me-3 text-decoration-none" id="backToSettings">
                                <i class="fas fa-arrow-left fs-5 text-secondary"></i>
                            </button>
                            <h3 class="fw-bold mb-0">Language</h3>
                        </div>
                    </div>
                `;
                $("#main-content").html(pageHeader + (languageContent || ''));
                $("#pageTitle").text("Language");

                if (typeof window.initLanguagePage === 'function') {
                    window.initLanguagePage();
                } else {
                    console.error("initLanguagePage is not defined. Ensure language.js is loaded and defines this function globally.");
                }

            }).fail(function() {
                showToast('Failed to load language page.', 'error');
                $("#main-content").html(`<div class='mt-4 text-danger'><h4>Error Loading Page</h4><p>Could not load the language content. Please try again.</p></div>`);
            });
        }
        else { // Fallback for other pages like tracking, archived, etc.
            $("#main-content").html(`<div class='mt-4'><h4>${capitalize(target)} Page Content</h4><p>Content for ${capitalize(target)}.</p></div>`);
        }
    }

    // Initial load: Set 'home' as the default active page on load
    loadContent("home"); 

    // Handle sidebar navigation clicks
    $("[data-target]").on("click", function (e) {
        e.preventDefault();
        const target = $(this).data("target");
        loadContent(target);
    });

    // Handle clicks within the dynamically loaded settings items (delegated event)
    $(document).on('click', '.setting-item', function(e) {
        e.preventDefault();
        const setting = $(this).data('setting');
        
        // Pass the setting as target to loadContent
        loadContent(setting);
    });

    // Handle click on "Profile" in the top-right dropdown menu
    $(document).on('click', '[data-nav-target="profile-page"]', function(e) {
        e.preventDefault();
        loadContent('profile'); 
    });

    // Handle back button from sub-pages (like profile/general/language) to settings
    // This handler uses event delegation for elements dynamically added to the DOM.
    $(document).on('click', '#backToSettings', function(e) {
        e.preventDefault();
        loadContent('settings'); 
    });

    // Sidebar toggle for mobile and desktop
    $("#sidebarToggle").on("click", function () {
        $("#wrapper").toggleClass("toggled");
        $("body").toggleClass("sidebar-open"); 
        
        // NEW: Dynamically add/remove the overlay element
        if ($("body").hasClass("sidebar-open")) {
            // Append overlay if sidebar is opening and it's a mobile view
            if (! $('.sidebar-overlay').length && $(window).width() < 992) {
                $('body').append('<div class="sidebar-overlay"></div>');
            }
        } else {
            // Remove overlay if sidebar is closing
            $('.sidebar-overlay').remove();
        }
    });

    // Close sidebar when clicking outside on mobile (overlay click)
    // IMPORTANT: Event listener is now on the actual .sidebar-overlay element
    $(document).on('click', '.sidebar-overlay', function() {
        if ($(window).width() < 992) {
            $("#wrapper").removeClass("toggled");
            $("body").removeClass("sidebar-open");
            $(this).remove(); // Remove the clicked overlay
        }
    });
});