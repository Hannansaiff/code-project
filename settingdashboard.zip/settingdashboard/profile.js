// profile.js

// Define a global initialization function for the profile page
// This function will be called by script.js after profile.html is loaded.
window.initProfilePage = function() {
    console.log("Profile page functionality initialized.");

    // IMPORTANT: Use .off().on() with a namespace to prevent multiple bindings
    // if initProfilePage is called multiple times (e.g., navigating back and forth)

    // Handle form submission
    $(document).off('submit.profileForm').on('submit.profileForm', '#profileForm', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = $('#name').val().trim();
        const country = $('#country').val();
        const mobile = $('#mobile').val().trim();
        
        // Basic validation
        if (!name) {
            if (typeof window.showToast === 'function') { // Use window.showToast for global access
                window.showToast('Please enter your name', 'error');
            }
            $('#name').focus();
            return;
        }
        
        if (!mobile) {
            if (typeof window.showToast === 'function') {
                window.showToast('Please enter your mobile number', 'error');
            }
            $('#mobile').focus();
            return;
        }
        
        // Validate mobile number format (basic validation for Pakistani format)
        // This regex allows for optional +92 or 0 prefix, followed by 10 digits.
        const mobilePattern = /^(\+92|0)?[0-9]{10}$/; 
        if (!mobilePattern.test(mobile.replace(/\s+/g, ''))) {
            if (typeof window.showToast === 'function') {
                window.showToast('Please enter a valid mobile number (e.g., 03xxxxxxxxx or +923xxxxxxxxx)', 'error');
            }
            $('#mobile').focus();
            return;
        }
        
        // Show loading state
        const $submitBtn = $(this).find('.btn-update'); // Select within the current form
        const originalText = $submitBtn.text();
        $submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
        
        // Simulate API call
        setTimeout(function() {
            // Reset button state
            $submitBtn.prop('disabled', false).text(originalText);
            
            // Show success message using the global showToast function
            if (typeof window.showToast === 'function') {
                window.showToast('Profile updated successfully!', 'success');
            }
            
            // Update navbar user name if it exists
            if (name && $('.user-name').length) {
                $('.user-name').text(name);
            }
            
        }, 1500); // Simulate 1.5 seconds loading
    });
    
    // Handle input formatting
    $(document).off('input.mobileFormat').on('input.mobileFormat', '#mobile', function() {
        let value = $(this).val().replace(/\D/g, ''); // Remove non-digits
        
        // Basic formatting for Pakistani numbers. Can be expanded for other countries.
        if (value.startsWith('92')) {
            value = '+' + value;
        } else if (value.length > 0 && !value.startsWith('0') && value.length < 11) {
            value = '0' + value; // Prepend '0' if it's a 10-digit number without a leading zero
        }
        
        // Limit length
        if (value.startsWith('+92')) {
            value = value.substring(0, 13); // +92 (3 chars) + 10 digits = 13
        } else {
            value = value.substring(0, 11); // 0 (1 char) + 10 digits = 11
        }
        
        $(this).val(value);
    });
    
    // Handle country change
    $(document).off('change.countryChange').on('change.countryChange', '#country', function() {
        const country = $(this).val();
        const $mobile = $('#mobile');
        
        // Clear mobile number when country changes
        $mobile.val('');
        
        // Update placeholder based on country
        switch(country) {
            case 'Pakistan':
                $mobile.attr('placeholder', '0300xxxxxxxx');
                break;
            case 'United States':
            case 'Canada':
                $mobile.attr('placeholder', '+1 (XXX) XXX-XXXX');
                break;
            case 'United Kingdom':
                $mobile.attr('placeholder', '+44 XXXXX XXXXXX');
                break;
            case 'India':
                $mobile.attr('placeholder', '+91 XXXXX XXXXX');
                break;
            default:
                $mobile.attr('placeholder', 'Enter mobile number');
        }
    });
    
    // Handle name input capitalization
    $(document).off('blur.nameCapitalize').on('blur.nameCapitalize', '#name', function() {
        const value = $(this).val();
        if (value) {
            // Capitalize first letter of each word
            const capitalized = value.replace(/\b\w/g, function(match) {
                return match.toUpperCase();
            });
            $(this).val(capitalized);
        }
    });
};

// No global event listeners here for document.on('profileContentLoaded')
// as script.js will directly call window.initProfilePage() when needed.