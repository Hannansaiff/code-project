// general.js

// Define a global initialization function for the general settings page
// This function will be called by script.js after general.html is loaded.
window.initGeneralPage = function() {
    console.log("General settings page functionality initialized.");

    // IMPORTANT: Use .off().on() with a namespace to prevent multiple bindings
    // if initGeneralPage is called multiple times (e.g., navigating back and forth)

    // Handle form submission for general settings
    $(document).off('submit.generalForm').on('submit.generalForm', '#generalSettingsForm', function(e) {
        e.preventDefault();
        
        const time = $('#time').val();
        const date = $('#date').val();
        // const timeFormat = $('#timeFormat').val(); // This is readonly, but captured for demonstration

        // Basic validation
        if (!time || !date) {
            // Check if showToast function is available (from script.js)
            if (typeof window.showToast === 'function') { // Use window.showToast for global access
                window.showToast('Please select both time and date.', 'error');
            }
            return;
        }

        // Show loading state on the update button
        const $submitBtn = $(this).find('.btn-update'); // Select within the current form
        const originalText = $submitBtn.text();
        $submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');

        // Simulate an API call with a delay
        setTimeout(function() {
            $submitBtn.prop('disabled', false).text(originalText); // Restore button state
            if (typeof window.showToast === 'function') {
                window.showToast(`General settings updated! Time: ${time}, Date: ${date}`, 'success');
            }
        }, 1500); // Simulate 1.5 seconds of loading
    });

    // Add any other specific event listeners or logic for general.html elements here.
    // For example, if you had a dropdown for time format selection:
    // $(document).off('change.timeFormatSelect').on('change.timeFormatSelect', '#timeFormatSelect', function() { ... });
};

// No global event listeners here for document.on('generalContentLoaded')
// as script.js will directly call window.initGeneralPage() when needed.